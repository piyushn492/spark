<?php

include_once("connect.php");
$sql = "DELETE FROM page WHERE id='".$_GET['$id']."'";

if (mysqli_query($conn, $sql)) {
    header('Location: viewpage.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>