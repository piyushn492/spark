<?php

session_start();
ob_start();
?>
<?php include_once('header.php'); ?>

    <div class="container-fluid">
      <div class="row">
<?php include_once('sidebar.php'); ?>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		<h1 class="sub-header">View Doctor</h1>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  
                  <th>Name</th>
                  <th>Address</th>
                  <th>Phone</th>
                  <th>Email</th>
				  <th>Designation</th>
				  
                </tr>
              </thead>
			  
			  <?php
include_once("connect.php");
$sql = "SELECT * FROM doctor";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
			echo"<tbody>";
			echo"<tr>";
			echo"<td>".$row["dname"]."</td>";
			echo"<td>".$row["daddress"]."</td>";
			echo"<td>".$row["dphone"]."</td>";
			echo"<td>".$row["demail"]."</td>";
			echo"<td>".$row["dtype"]."</td>";
			
			echo"</tr>";
			echo"</tbody>";
			}
} else {
    echo "0 results";
}
mysqli_close($conn);
?>
              
                  
               
            </table>
          </div>
        </div>
      </div>
    </div>

  <?php include_once('footer.php');?>