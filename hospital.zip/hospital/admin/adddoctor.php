<?php

include_once("connect.php");
$sql = "INSERT INTO doctor ( dname, daddress, dphone, demail, dtype)
VALUES ('".$_GET['name']."', '".$_GET['address']."','".$_GET['phone']."','".$_GET['email']."','".$_GET['type']."');";
if (mysqli_query($conn, $sql)) {
    header('Location: viewdoctor.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>