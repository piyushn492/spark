<?php
include_once("connect.php");
$sql = "INSERT INTO patient ( pname, paddress, pphone, padate, prdate, pdisease, pdoctor )
VALUES ('".$_GET['name']."', '".$_GET['address']."','".$_GET['phone']."','".$_GET['adate']."','".$_GET['rdate']."','".$_GET['disease']."','".$_GET['doctor']."');";
if (mysqli_query($conn, $sql)) {
    header('Location: viewpatient.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>