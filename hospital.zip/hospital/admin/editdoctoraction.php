<?php

session_start();
ob_start();
?>
<?php include_once('header.php'); ?>

    <div class="container-fluid">
      <div class="row">
           <?php include_once('sidebar.php'); ?>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Edit Record</h1>
           <div class="mydiv">
             <form action="adddoctor.php" method="get" class="form-horizontal" role="form">
				
              
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name="name" value=<?php include_once("connect.php");
							$sql = "SELECT dname FROM doctor WHERE did='".$_GET['$id']."'";
							$result = mysqli_query($conn, $sql);
							if (mysqli_num_rows($result) > 0) {
							while($row = mysqli_fetch_assoc($result)) {
							echo $row['dname']; }}
							else {
							echo "0 results";
							}
							mysqli_close($conn);?> class="form-control" autofocus>
                        
                    </div>
                </div>
				 <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name="address"  placeholder="Address" class="form-control" autofocus>
                        
                    </div>
                </div>
				 <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Phone no</label>
                    <div class="col-sm-9">
                        <input type="text" id="email" name="phone" placeholder="Phone no" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" name="email"  placeholder="Email" class="form-control">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Designation Type</label>
                    <div class="col-sm-9">
                        <input type="text" id="email" name="type" placeholder="Designation Type" class="form-control">
                    </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox">I accept <a href="#">terms</a>
                            </label>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Save</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->
        
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="js/holder.min.js"></script>
  
  </body>
</html>
