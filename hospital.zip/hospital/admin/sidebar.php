        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="dashboard.php">Home <span class="sr-only">(current)</span></a></li>
			 <li><a href="insertdoctor.php">Add Doctor</a></li>
            <li><a href="editdoctor.php">Edit Doctor</a></li>
            <li><a href="deletedoctor.php">Delete Doctor</a></li>
            <li><a href="viewdoctor.php">View Doctor</a></li>
          </ul>
          <ul class="nav nav-sidebar">
            <li><a href="insertpatient.php">Add Patient</a></li>
            <li><a href="editpatient.php">Edit Patient</a></li>
            <li><a href="deletepatient.php">Delete patient</a></li>
            <li><a href="viewpatient.php">View Patient</a></li>
          </ul>
		  <ul class="nav nav-sidebar">
            <li class="active"><a href="dashboard.php">Page Management <span class="sr-only">(current)</span></a></li>
            <li><a href="addpage.php">Add</a></li>
            <li><a href="updatepage.php">Update</a></li>
            <li><a href="deletepage.php">Delete</a></li>
			<li><a href="viewpage.php">View</a></li>
          </ul>
         
        </div>