<?php

session_start();
ob_start();
?>
<?php include_once('header.php'); ?>

    <div class="container-fluid">
      <div class="row">
           <?php include_once('sidebar.php'); ?>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Add Record</h1>
           <div class="mydiv">
             <form action="addpatient.php" method="get" class="form-horizontal" role="form">
				
              
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name="name" placeholder="Name" class="form-control" autofocus>
                        
                    </div>
                </div>
				 <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name ="address"  placeholder="Address" class="form-control" autofocus>
                        
                    </div>
                </div>
				
				 <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Appointment Date</label>
                    <div class="col-sm-9">
                        <input type="date" id="email" name="adate" class="form-control">
                    </div>
                </div>
				 <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Releasing Date</label>
                    <div class="col-sm-9">
                        <input type="date" id="email" name="rdate"  class="form-control">
                    </div>
                </div>
				
				 <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Phone no</label>
                    <div class="col-sm-9">
                        <input type="text" id="email" name="phone" placeholder="Phone no" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Type Of disease</label>
                    <div class="col-sm-9">
                        <input type="text" id="email"  name="disease" placeholder="Type Of disease" class="form-control">
                    </div>
                </div>
				<div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Consulting Doctor Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="email" name ="doctor" placeholder="Consulting Doctor Name" class="form-control">
                    </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox">I accept <a href="#">terms</a>
                            </label>
                        </div>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                    </div>
                </div>
            </form> <!-- /form -->
			
				
			
        </div> <!-- ./container -->
        
        </div>
      </div>
    </div>

     <?php include_once('footer.php'); ?>