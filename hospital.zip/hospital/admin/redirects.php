<?php
session_start();
include_once("connect.php");
$name = $_GET['uname'];
$sql = "SELECT uname,upass  FROM user WHERE uname='".$_GET['uname']."' AND upass='".$_GET['upass']."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
	
	$_SESSION['uname'] = $name;
   header('Location: dashboard.php');
 
} else {
    echo "0 results";
}

mysqli_close($conn);
?>