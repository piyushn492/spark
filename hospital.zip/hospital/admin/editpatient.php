<?php

session_start();
ob_start();
?>
<?php include_once('header.php'); ?>

    <div class="container-fluid">
      <div class="row">
<?php include_once('sidebar.php'); ?>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		<h1 class="sub-header">Edit Patient</h1>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  
                  <th>Name</th>
                  <th>Address</th>
				  <th>Phone No</th>
                  <th>Appointment Date</th>
                  <th>Releasing Date</th>
				  <th>Type Of Disease</th>
				  <th>Consulting Doctor Name</th>
				  <th>Action</th>
                </tr>
              </thead>
			  
			  <?php
include_once("connect.php");
$sql = "SELECT  pname, paddress, pphone, DATE_FORMAT(padate, '%d/%m/%Y') AS pa, DATE_FORMAT(prdate, '%d/%m/%Y') AS pr, pdisease, pdoctor FROM patient";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
			echo"<tbody>";
			echo"<tr>";
			echo"<td>".$row["pname"]."</td>";
			echo"<td>".$row["paddress"]."</td>";
			echo"<td>".$row["pphone"]."</td>";
			echo"<td>".$row["pa"]."</td>";
			echo"<td>".$row["pr"]."</td>";
			echo"<td>".$row["pdisease"]."</td>";
			echo"<td>".$row["pdoctor"]."</td>";
			?>
			<td><a href="editpatientaction.php?$id= <?php echo $row["pid"]; ?>"><input type="submit" name="submit" value="Edit" class="btn btn-lg btn-primary btn-block" /></a></td>
			<?php
			echo"</tr>";
			echo"</tbody>";
			}
} else {
    echo "0 results";
}
mysqli_close($conn);
?>
              
                  
               
            </table>
          </div>
        </div>
      </div>
    </div>

  <?php include_once('footer.php');?>