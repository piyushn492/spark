<?php

session_start();
ob_start();
?>
<?php include_once('header.php'); ?>

    <div class="container-fluid">
      <div class="row">
<?php include_once('sidebar.php'); ?>

        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		<h1 class="sub-header">View Page</h1>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  
                  <th>Title</th>
                  <th>Content</th>
				  <th>Image</th>
                  <th>Date</th>

                </tr>
              </thead>
			  
			  <?php
include_once("connect.php");
$sql = "SELECT  id, title, content, image, DATE_FORMAT(date, '%d/%m/%Y') AS da FROM page";

$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
			echo"<tbody>";
			echo"<tr>";
			echo"<td>".$row["title"]."</td>";
			echo"<td>".$row["content"]."</td>";
			echo"<td>".$row["image"]."</td>";
			echo"<td>".$row["da"]."</td>";
			
			
			echo"</tr>";
			echo"</tbody>";
			}
} else {
    echo "0 results";
}
mysqli_close($conn);
?>
              
                  
               
            </table>
          </div>
        </div>
      </div>
    </div>

  <?php include_once('footer.php');?>