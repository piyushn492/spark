<?php

include_once("connect.php");
$sql = "DELETE FROM doctor WHERE did='".$_GET['$id']."'";

if (mysqli_query($conn, $sql)) {
    header('Location: viewdoctor.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>