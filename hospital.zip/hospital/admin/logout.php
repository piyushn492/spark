<?php

session_start();
if(!empty($_SESSION['uname'])){

unset($_SESSION['uname']);

 header('Location: index.html');

}

?>