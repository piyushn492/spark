<?php

include_once("connect.php");
$sql = "DELETE FROM patient WHERE pid='".$_GET['$id']."'";

if (mysqli_query($conn, $sql)) {
    header('Location: viewpatient.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>