<?php

include_once("connect.php");
$sql = "INSERT INTO page ( title, content, pic, date)
VALUES ('".$_GET['title']."', '".$_GET['content']."','".$_GET['image']."', CURDATE() );";
if (mysqli_query($conn, $sql)) {
    header('Location: viewpage.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>