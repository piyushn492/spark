<?php include('header.php'); ?>
 <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
         <?php include('sidebar.php') ?>
     
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		

<div class="row placeholders">
 
  <h1 class="well">Insert Member Form</h1>
	<div class="col-lg-12 well">
	<div class="row">
	

<form action="insertdata.php" method="post" enctype="multipart/form-data">
                     <div class="col-sm-12">
						<div class="row">
						  
							<div class="col-sm-6 form-group">
								<label>Old form id</label>
								<input type="text" value = "" name="oldformid" class="form-control">
							</div>
							<div class="col-sm-6 form-group">
								<label>New firm id</label>
								<input type="text" value = "" name="newfirmid" class="form-control">
							</div>
						</div>		
							<div class="row">
							<div class="col-sm-6 form-group">
								<label>Firm name</label>
								<input type="text" value = "" name="firmname" class="form-control">
							</div>
							<div class="col-sm-6 form-group">
								<label>Member category</label>
								<input type="text" value = "" name="membercategory" class="form-control">
							</div>
						</div>		
						<div class="form-group">
							<label>Firm category</label>
							<input type="text" value = "" name="firmcategory" class="form-control">
						</div>	
						<div class="row">
							<div class="col-sm-4 form-group">
								<label>Area</label>
								<input type="text" value = "" name="area" class="form-control">
							</div>	
							<div class="col-sm-4 form-group">
								<label>Office landline no</label>
								<input type="text" value = "" name="officelandlineno" class="form-control">
							</div>	
							<div class="col-sm-4 form-group">
								<label>Office mobile No</label>
								<input type="text" value = "" name="officemobileno" class="form-control">
							</div>		
						</div>
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Fax no</label>
								<input type="text" value = "" name="faxno" class="form-control">
							</div>		
							<div class="col-sm-6 form-group">
								<label>Mail id</label>
								<input type="text" value = "" name="mailid" class="form-control">
							</div>	
						</div>	
                    	<div class="row">					
					<div class="col-sm-4 form-group">
						<label>Reprasentative name</label>
						<input type="text" value = "" name="representativename" class="form-control">
					</div>		
					<div class="col-sm-4 form-group">
						<label>Mobile no</label>
						<input type="text" value = "" name="mobileno" class="form-control">
					</div>	
					<div class="col-sm-4 form-group">
						<label>Image</label>
						<input type="file" name="fileToUpload" />
                        
					</div>
					</div>
					<input type="submit" name = "submit" value = "Submit" class="btn btn-lg btn-info"/>					
					</div>
               </form>
			
				
				</div>
				
				
				<?php


$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
		 
 if(isset($_POST['submit'])){

 $oldfirmid = $_POST['oldformid'];
 $newfirmid = $_POST['newfirmid'];
 $firmname =  $_POST['firmname'];
 $membercategory = $_POST['membercategory'];
 $firmcategory = $_POST['firmcategory'];
 $area = $_POST['area'];
 $officelandlineno = $_POST['officelandlineno'];
 $officemobileno = $_POST['officemobileno'];
 $faxno = $_POST['faxno'];
 $mailid = $_POST['mailid'];
 $representativename = $_POST['representativename'];
 $mobileno = $_POST['mobileno'];
 
 
 
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        } else {
        echo "File is not an image.";
        $uploadOk = 0;
                     }
	
	// Check if file already exists
       if (file_exists($target_file)){
       echo "Sorry, file already exists.";
       $uploadOk = 0;
        }
    // Check file size
       if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
        }
      // Allow certain file formats
         if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
         echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
         $uploadOk = 0;
          }
      // Check if $uploadOk is set to 0 by an error
         if ($uploadOk == 0) {
         echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
         } else {
         if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
          echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
          } else {
          echo "Sorry, there was an error uploading your file.";
          }
               }
 //$date = date('Y-m-d H:i:s');
$path = $_FILES['fileToUpload']['name'];
$sql  = "INSERT INTO members(old_firm_id,new_firm_id,firm_name,member_category,firm_category,area,office_landline_no,office_mobile_no,fax_no,mail_id,reprasentative_name,mobile_no,image)
 VALUES('$oldfirmid','$newfirmid','$firmname','$membercategory','$firmcategory','$area','$officelandlineno','$officemobileno','$faxno','$mailid','$representativename','$mobileno','$path')";
 

 
 if (mysqli_query($conn, $sql)) {
   echo "New record created successfully";
	
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
 mysqli_close($conn);
}



 
?>
	</div>

 
 

</div>
 <?php include('footer.php') ?>