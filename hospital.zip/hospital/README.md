HealthCare
==========

A responsive theme for commercial medical purpose. Built with HTML5, CSS3, Bootstrap framework. Google fonts, Font Awesome Icon integrated

==========

Bootstrap3 Powered
Backgroundg Slider
Multiple Page Options
Code & Content Optimized for Speed
Responsive Layout
Clean Code
Cross-browser Compatibility
CSS3 Animations
100% Fully Customisable
No Hardcoded Options
Sticky Header Options
Super Easy Installation & Setup With One Click Demo Installation
Custom Background
Font Awesome Icon Integration
Google Fonts
Advanced Typography Options
Extensive Documentation
Built with HTML5 & CSS3
Strong focus on Typography, Usability and Overall User Experience
Clean and Modern Design – can be used for any type of website
Lifetime Update & Free Support
